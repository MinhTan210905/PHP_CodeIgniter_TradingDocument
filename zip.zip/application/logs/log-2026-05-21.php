<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-05-21 17:00:50 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials\footer.php 43
