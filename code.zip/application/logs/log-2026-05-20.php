<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-05-20 16:51:30 --> Config Class Initialized
INFO - 2026-05-20 16:51:30 --> Hooks Class Initialized
DEBUG - 2026-05-20 16:51:30 --> UTF-8 Support Enabled
INFO - 2026-05-20 16:51:30 --> Utf8 Class Initialized
INFO - 2026-05-20 16:51:30 --> URI Class Initialized
DEBUG - 2026-05-20 16:51:30 --> No URI present. Default controller set.
INFO - 2026-05-20 16:51:30 --> Router Class Initialized
INFO - 2026-05-20 16:51:30 --> Output Class Initialized
INFO - 2026-05-20 16:51:30 --> Security Class Initialized
DEBUG - 2026-05-20 16:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 16:51:30 --> Input Class Initialized
INFO - 2026-05-20 16:51:31 --> Language Class Initialized
INFO - 2026-05-20 16:51:31 --> Loader Class Initialized
INFO - 2026-05-20 16:51:31 --> Helper loaded: url_helper
INFO - 2026-05-20 16:51:31 --> Database Driver Class Initialized
DEBUG - 2026-05-20 16:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 16:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 16:51:31 --> Controller Class Initialized
INFO - 2026-05-20 16:51:31 --> Model "Trade_model" initialized
INFO - 2026-05-20 16:51:31 --> Model "Comment_model" initialized
INFO - 2026-05-20 16:51:31 --> Model "Rating_model" initialized
INFO - 2026-05-20 16:51:31 --> Model "Message_model" initialized
INFO - 2026-05-20 16:51:31 --> Model "Order_model" initialized
INFO - 2026-05-20 16:51:31 --> Model "Setting_model" initialized
INFO - 2026-05-20 16:51:31 --> Helper loaded: form_helper
DEBUG - 2026-05-20 16:51:31 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 16:51:31 --> Upload Class Initialized
INFO - 2026-05-20 16:51:31 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/header.php
INFO - 2026-05-20 16:51:31 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\home.php
INFO - 2026-05-20 16:51:31 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/footer.php
INFO - 2026-05-20 16:51:31 --> Final output sent to browser
DEBUG - 2026-05-20 16:51:31 --> Total execution time: 0.4400
INFO - 2026-05-20 16:51:31 --> Config Class Initialized
INFO - 2026-05-20 16:51:31 --> Hooks Class Initialized
DEBUG - 2026-05-20 16:51:31 --> UTF-8 Support Enabled
INFO - 2026-05-20 16:51:31 --> Utf8 Class Initialized
INFO - 2026-05-20 16:51:31 --> URI Class Initialized
INFO - 2026-05-20 16:51:31 --> Router Class Initialized
INFO - 2026-05-20 16:51:31 --> Output Class Initialized
INFO - 2026-05-20 16:51:31 --> Security Class Initialized
DEBUG - 2026-05-20 16:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 16:51:31 --> Input Class Initialized
INFO - 2026-05-20 16:51:31 --> Language Class Initialized
INFO - 2026-05-20 16:51:31 --> Loader Class Initialized
INFO - 2026-05-20 16:51:31 --> Helper loaded: url_helper
INFO - 2026-05-20 16:51:31 --> Database Driver Class Initialized
DEBUG - 2026-05-20 16:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 16:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 16:51:31 --> Controller Class Initialized
INFO - 2026-05-20 16:51:31 --> Model "Trade_model" initialized
INFO - 2026-05-20 16:51:31 --> Model "Order_model" initialized
INFO - 2026-05-20 16:51:31 --> Model "Seller_model" initialized
INFO - 2026-05-20 16:51:31 --> Model "Rating_model" initialized
INFO - 2026-05-20 16:51:31 --> Model "Message_model" initialized
INFO - 2026-05-20 16:51:31 --> Helper loaded: form_helper
INFO - 2026-05-20 16:51:31 --> Form Validation Class Initialized
DEBUG - 2026-05-20 16:51:31 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 16:51:31 --> Final output sent to browser
DEBUG - 2026-05-20 16:51:31 --> Total execution time: 0.1245
INFO - 2026-05-20 16:51:33 --> Config Class Initialized
INFO - 2026-05-20 16:51:33 --> Hooks Class Initialized
DEBUG - 2026-05-20 16:51:33 --> UTF-8 Support Enabled
INFO - 2026-05-20 16:51:33 --> Utf8 Class Initialized
INFO - 2026-05-20 16:51:33 --> URI Class Initialized
INFO - 2026-05-20 16:51:33 --> Router Class Initialized
INFO - 2026-05-20 16:51:33 --> Output Class Initialized
INFO - 2026-05-20 16:51:33 --> Security Class Initialized
DEBUG - 2026-05-20 16:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 16:51:33 --> Input Class Initialized
INFO - 2026-05-20 16:51:33 --> Language Class Initialized
INFO - 2026-05-20 16:51:33 --> Loader Class Initialized
INFO - 2026-05-20 16:51:33 --> Helper loaded: url_helper
INFO - 2026-05-20 16:51:33 --> Database Driver Class Initialized
DEBUG - 2026-05-20 16:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 16:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 16:51:33 --> Controller Class Initialized
INFO - 2026-05-20 16:51:33 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 16:51:33 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 16:51:33 --> Helper loaded: form_helper
INFO - 2026-05-20 16:51:33 --> Form Validation Class Initialized
INFO - 2026-05-20 16:51:33 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\auth/register.php
INFO - 2026-05-20 16:51:33 --> Final output sent to browser
DEBUG - 2026-05-20 16:51:33 --> Total execution time: 0.1850
INFO - 2026-05-20 16:51:57 --> Config Class Initialized
INFO - 2026-05-20 16:51:57 --> Hooks Class Initialized
DEBUG - 2026-05-20 16:51:57 --> UTF-8 Support Enabled
INFO - 2026-05-20 16:51:57 --> Utf8 Class Initialized
INFO - 2026-05-20 16:51:57 --> URI Class Initialized
INFO - 2026-05-20 16:51:57 --> Router Class Initialized
INFO - 2026-05-20 16:51:57 --> Output Class Initialized
INFO - 2026-05-20 16:51:57 --> Security Class Initialized
DEBUG - 2026-05-20 16:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 16:51:57 --> Input Class Initialized
INFO - 2026-05-20 16:51:57 --> Language Class Initialized
INFO - 2026-05-20 16:51:57 --> Loader Class Initialized
INFO - 2026-05-20 16:51:57 --> Helper loaded: url_helper
INFO - 2026-05-20 16:51:57 --> Database Driver Class Initialized
DEBUG - 2026-05-20 16:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 16:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 16:51:58 --> Controller Class Initialized
INFO - 2026-05-20 16:51:58 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 16:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 16:51:58 --> Helper loaded: form_helper
INFO - 2026-05-20 16:51:58 --> Form Validation Class Initialized
INFO - 2026-05-20 16:51:58 --> Config Class Initialized
INFO - 2026-05-20 16:51:58 --> Hooks Class Initialized
DEBUG - 2026-05-20 16:51:58 --> UTF-8 Support Enabled
INFO - 2026-05-20 16:51:58 --> Utf8 Class Initialized
INFO - 2026-05-20 16:51:58 --> URI Class Initialized
INFO - 2026-05-20 16:51:58 --> Router Class Initialized
INFO - 2026-05-20 16:51:58 --> Output Class Initialized
INFO - 2026-05-20 16:51:58 --> Security Class Initialized
DEBUG - 2026-05-20 16:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 16:51:58 --> Input Class Initialized
INFO - 2026-05-20 16:51:58 --> Language Class Initialized
INFO - 2026-05-20 16:51:58 --> Loader Class Initialized
INFO - 2026-05-20 16:51:58 --> Helper loaded: url_helper
INFO - 2026-05-20 16:51:58 --> Database Driver Class Initialized
DEBUG - 2026-05-20 16:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 16:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 16:51:58 --> Controller Class Initialized
INFO - 2026-05-20 16:51:58 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 16:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 16:51:58 --> Helper loaded: form_helper
INFO - 2026-05-20 16:51:58 --> Form Validation Class Initialized
INFO - 2026-05-20 16:51:58 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\auth/register.php
INFO - 2026-05-20 16:51:58 --> Final output sent to browser
DEBUG - 2026-05-20 16:51:58 --> Total execution time: 0.0468
INFO - 2026-05-20 17:01:33 --> Config Class Initialized
INFO - 2026-05-20 17:01:33 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:01:33 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:01:33 --> Utf8 Class Initialized
INFO - 2026-05-20 17:01:33 --> URI Class Initialized
DEBUG - 2026-05-20 17:01:33 --> No URI present. Default controller set.
INFO - 2026-05-20 17:01:33 --> Router Class Initialized
INFO - 2026-05-20 17:01:33 --> Output Class Initialized
INFO - 2026-05-20 17:01:33 --> Security Class Initialized
DEBUG - 2026-05-20 17:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:01:33 --> Input Class Initialized
INFO - 2026-05-20 17:01:33 --> Language Class Initialized
INFO - 2026-05-20 17:01:33 --> Loader Class Initialized
INFO - 2026-05-20 17:01:33 --> Helper loaded: url_helper
INFO - 2026-05-20 17:01:33 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:01:33 --> Controller Class Initialized
INFO - 2026-05-20 17:01:33 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:01:33 --> Model "Comment_model" initialized
INFO - 2026-05-20 17:01:33 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:01:33 --> Model "Message_model" initialized
INFO - 2026-05-20 17:01:33 --> Model "Order_model" initialized
INFO - 2026-05-20 17:01:33 --> Model "Setting_model" initialized
INFO - 2026-05-20 17:01:33 --> Helper loaded: form_helper
DEBUG - 2026-05-20 17:01:33 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:01:33 --> Upload Class Initialized
INFO - 2026-05-20 17:01:33 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/header.php
INFO - 2026-05-20 17:01:33 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\home.php
INFO - 2026-05-20 17:01:33 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/footer.php
INFO - 2026-05-20 17:01:33 --> Final output sent to browser
DEBUG - 2026-05-20 17:01:33 --> Total execution time: 0.1751
INFO - 2026-05-20 17:01:34 --> Config Class Initialized
INFO - 2026-05-20 17:01:34 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:01:34 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:01:34 --> Utf8 Class Initialized
INFO - 2026-05-20 17:01:34 --> URI Class Initialized
INFO - 2026-05-20 17:01:34 --> Router Class Initialized
INFO - 2026-05-20 17:01:34 --> Output Class Initialized
INFO - 2026-05-20 17:01:34 --> Security Class Initialized
DEBUG - 2026-05-20 17:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:01:34 --> Input Class Initialized
INFO - 2026-05-20 17:01:34 --> Language Class Initialized
INFO - 2026-05-20 17:01:34 --> Loader Class Initialized
INFO - 2026-05-20 17:01:34 --> Helper loaded: url_helper
INFO - 2026-05-20 17:01:34 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:01:34 --> Controller Class Initialized
INFO - 2026-05-20 17:01:34 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:01:34 --> Model "Order_model" initialized
INFO - 2026-05-20 17:01:34 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:01:34 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:01:34 --> Model "Message_model" initialized
INFO - 2026-05-20 17:01:34 --> Helper loaded: form_helper
INFO - 2026-05-20 17:01:34 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:01:34 --> Final output sent to browser
DEBUG - 2026-05-20 17:01:34 --> Total execution time: 0.0966
INFO - 2026-05-20 17:02:08 --> Config Class Initialized
INFO - 2026-05-20 17:02:08 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:02:08 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:02:08 --> Utf8 Class Initialized
INFO - 2026-05-20 17:02:08 --> URI Class Initialized
INFO - 2026-05-20 17:02:08 --> Router Class Initialized
INFO - 2026-05-20 17:02:08 --> Output Class Initialized
INFO - 2026-05-20 17:02:08 --> Security Class Initialized
DEBUG - 2026-05-20 17:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:02:08 --> Input Class Initialized
INFO - 2026-05-20 17:02:08 --> Language Class Initialized
INFO - 2026-05-20 17:02:08 --> Loader Class Initialized
INFO - 2026-05-20 17:02:08 --> Helper loaded: url_helper
INFO - 2026-05-20 17:02:08 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:02:08 --> Controller Class Initialized
INFO - 2026-05-20 17:02:08 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:02:08 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:02:08 --> Helper loaded: form_helper
INFO - 2026-05-20 17:02:08 --> Form Validation Class Initialized
INFO - 2026-05-20 17:02:08 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\auth/register.php
INFO - 2026-05-20 17:02:08 --> Final output sent to browser
DEBUG - 2026-05-20 17:02:08 --> Total execution time: 0.0571
INFO - 2026-05-20 17:02:39 --> Config Class Initialized
INFO - 2026-05-20 17:02:39 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:02:39 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:02:39 --> Utf8 Class Initialized
INFO - 2026-05-20 17:02:39 --> URI Class Initialized
INFO - 2026-05-20 17:02:39 --> Router Class Initialized
INFO - 2026-05-20 17:02:39 --> Output Class Initialized
INFO - 2026-05-20 17:02:39 --> Security Class Initialized
DEBUG - 2026-05-20 17:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:02:39 --> Input Class Initialized
INFO - 2026-05-20 17:02:39 --> Language Class Initialized
INFO - 2026-05-20 17:02:39 --> Loader Class Initialized
INFO - 2026-05-20 17:02:39 --> Helper loaded: url_helper
INFO - 2026-05-20 17:02:39 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:02:39 --> Controller Class Initialized
INFO - 2026-05-20 17:02:39 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:02:39 --> Helper loaded: form_helper
INFO - 2026-05-20 17:02:39 --> Form Validation Class Initialized
INFO - 2026-05-20 17:02:39 --> Email Class Initialized
INFO - 2026-05-20 17:02:40 --> Language file loaded: language/english/email_lang.php
INFO - 2026-05-20 17:02:43 --> Config Class Initialized
INFO - 2026-05-20 17:02:43 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:02:43 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:02:43 --> Utf8 Class Initialized
INFO - 2026-05-20 17:02:43 --> URI Class Initialized
INFO - 2026-05-20 17:02:43 --> Router Class Initialized
INFO - 2026-05-20 17:02:43 --> Output Class Initialized
INFO - 2026-05-20 17:02:43 --> Security Class Initialized
DEBUG - 2026-05-20 17:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:02:43 --> Input Class Initialized
INFO - 2026-05-20 17:02:43 --> Language Class Initialized
INFO - 2026-05-20 17:02:43 --> Loader Class Initialized
INFO - 2026-05-20 17:02:43 --> Helper loaded: url_helper
INFO - 2026-05-20 17:02:43 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:02:43 --> Controller Class Initialized
INFO - 2026-05-20 17:02:43 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:02:43 --> Helper loaded: form_helper
INFO - 2026-05-20 17:02:43 --> Form Validation Class Initialized
INFO - 2026-05-20 17:02:43 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\auth/verify_otp.php
INFO - 2026-05-20 17:02:43 --> Final output sent to browser
DEBUG - 2026-05-20 17:02:43 --> Total execution time: 0.0377
INFO - 2026-05-20 17:03:14 --> Config Class Initialized
INFO - 2026-05-20 17:03:14 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:03:14 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:03:14 --> Utf8 Class Initialized
INFO - 2026-05-20 17:03:14 --> URI Class Initialized
INFO - 2026-05-20 17:03:14 --> Router Class Initialized
INFO - 2026-05-20 17:03:14 --> Output Class Initialized
INFO - 2026-05-20 17:03:14 --> Security Class Initialized
DEBUG - 2026-05-20 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:03:14 --> Input Class Initialized
INFO - 2026-05-20 17:03:14 --> Language Class Initialized
INFO - 2026-05-20 17:03:14 --> Loader Class Initialized
INFO - 2026-05-20 17:03:14 --> Helper loaded: url_helper
INFO - 2026-05-20 17:03:14 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:03:14 --> Controller Class Initialized
INFO - 2026-05-20 17:03:14 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:03:14 --> Helper loaded: form_helper
INFO - 2026-05-20 17:03:14 --> Form Validation Class Initialized
INFO - 2026-05-20 17:03:14 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\auth/register.php
INFO - 2026-05-20 17:03:14 --> Final output sent to browser
DEBUG - 2026-05-20 17:03:14 --> Total execution time: 0.0576
INFO - 2026-05-20 17:03:59 --> Config Class Initialized
INFO - 2026-05-20 17:03:59 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:03:59 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:03:59 --> Utf8 Class Initialized
INFO - 2026-05-20 17:03:59 --> URI Class Initialized
INFO - 2026-05-20 17:03:59 --> Router Class Initialized
INFO - 2026-05-20 17:03:59 --> Output Class Initialized
INFO - 2026-05-20 17:03:59 --> Security Class Initialized
DEBUG - 2026-05-20 17:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:03:59 --> Input Class Initialized
INFO - 2026-05-20 17:03:59 --> Language Class Initialized
INFO - 2026-05-20 17:03:59 --> Loader Class Initialized
INFO - 2026-05-20 17:03:59 --> Helper loaded: url_helper
INFO - 2026-05-20 17:03:59 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:03:59 --> Controller Class Initialized
INFO - 2026-05-20 17:03:59 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:03:59 --> Helper loaded: form_helper
INFO - 2026-05-20 17:03:59 --> Form Validation Class Initialized
INFO - 2026-05-20 17:03:59 --> Email Class Initialized
INFO - 2026-05-20 17:04:00 --> Language file loaded: language/english/email_lang.php
INFO - 2026-05-20 17:04:02 --> Config Class Initialized
INFO - 2026-05-20 17:04:02 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:04:02 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:04:02 --> Utf8 Class Initialized
INFO - 2026-05-20 17:04:03 --> URI Class Initialized
INFO - 2026-05-20 17:04:03 --> Router Class Initialized
INFO - 2026-05-20 17:04:03 --> Output Class Initialized
INFO - 2026-05-20 17:04:03 --> Security Class Initialized
DEBUG - 2026-05-20 17:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:04:03 --> Input Class Initialized
INFO - 2026-05-20 17:04:03 --> Language Class Initialized
INFO - 2026-05-20 17:04:03 --> Loader Class Initialized
INFO - 2026-05-20 17:04:03 --> Helper loaded: url_helper
INFO - 2026-05-20 17:04:03 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:04:03 --> Controller Class Initialized
INFO - 2026-05-20 17:04:03 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:04:03 --> Helper loaded: form_helper
INFO - 2026-05-20 17:04:03 --> Form Validation Class Initialized
INFO - 2026-05-20 17:04:03 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\auth/verify_otp.php
INFO - 2026-05-20 17:04:03 --> Final output sent to browser
DEBUG - 2026-05-20 17:04:03 --> Total execution time: 0.0412
INFO - 2026-05-20 17:04:44 --> Config Class Initialized
INFO - 2026-05-20 17:04:44 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:04:44 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:04:44 --> Utf8 Class Initialized
INFO - 2026-05-20 17:04:44 --> URI Class Initialized
INFO - 2026-05-20 17:04:44 --> Router Class Initialized
INFO - 2026-05-20 17:04:44 --> Output Class Initialized
INFO - 2026-05-20 17:04:44 --> Security Class Initialized
DEBUG - 2026-05-20 17:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:04:44 --> Input Class Initialized
INFO - 2026-05-20 17:04:44 --> Language Class Initialized
INFO - 2026-05-20 17:04:44 --> Loader Class Initialized
INFO - 2026-05-20 17:04:44 --> Helper loaded: url_helper
INFO - 2026-05-20 17:04:44 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:04:44 --> Controller Class Initialized
INFO - 2026-05-20 17:04:44 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:04:44 --> Helper loaded: form_helper
INFO - 2026-05-20 17:04:44 --> Form Validation Class Initialized
INFO - 2026-05-20 17:04:44 --> Config Class Initialized
INFO - 2026-05-20 17:04:44 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:04:44 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:04:44 --> Utf8 Class Initialized
INFO - 2026-05-20 17:04:44 --> URI Class Initialized
INFO - 2026-05-20 17:04:44 --> Router Class Initialized
INFO - 2026-05-20 17:04:44 --> Output Class Initialized
INFO - 2026-05-20 17:04:44 --> Security Class Initialized
DEBUG - 2026-05-20 17:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:04:44 --> Input Class Initialized
INFO - 2026-05-20 17:04:44 --> Language Class Initialized
INFO - 2026-05-20 17:04:44 --> Loader Class Initialized
INFO - 2026-05-20 17:04:44 --> Helper loaded: url_helper
INFO - 2026-05-20 17:04:44 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:04:44 --> Controller Class Initialized
INFO - 2026-05-20 17:04:44 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:04:44 --> Helper loaded: form_helper
INFO - 2026-05-20 17:04:44 --> Form Validation Class Initialized
INFO - 2026-05-20 17:04:44 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\auth/login.php
INFO - 2026-05-20 17:04:44 --> Final output sent to browser
DEBUG - 2026-05-20 17:04:44 --> Total execution time: 0.0322
INFO - 2026-05-20 17:05:02 --> Config Class Initialized
INFO - 2026-05-20 17:05:02 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:05:02 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:05:02 --> Utf8 Class Initialized
INFO - 2026-05-20 17:05:02 --> URI Class Initialized
INFO - 2026-05-20 17:05:02 --> Router Class Initialized
INFO - 2026-05-20 17:05:02 --> Output Class Initialized
INFO - 2026-05-20 17:05:02 --> Security Class Initialized
DEBUG - 2026-05-20 17:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:05:02 --> Input Class Initialized
INFO - 2026-05-20 17:05:02 --> Language Class Initialized
INFO - 2026-05-20 17:05:03 --> Loader Class Initialized
INFO - 2026-05-20 17:05:03 --> Helper loaded: url_helper
INFO - 2026-05-20 17:05:03 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:05:03 --> Controller Class Initialized
INFO - 2026-05-20 17:05:03 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:05:03 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:05:03 --> Helper loaded: form_helper
INFO - 2026-05-20 17:05:03 --> Form Validation Class Initialized
INFO - 2026-05-20 17:05:03 --> Final output sent to browser
DEBUG - 2026-05-20 17:05:03 --> Total execution time: 0.0990
INFO - 2026-05-20 17:05:09 --> Config Class Initialized
INFO - 2026-05-20 17:05:09 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:05:09 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:05:09 --> Utf8 Class Initialized
INFO - 2026-05-20 17:05:09 --> URI Class Initialized
INFO - 2026-05-20 17:05:09 --> Router Class Initialized
INFO - 2026-05-20 17:05:09 --> Output Class Initialized
INFO - 2026-05-20 17:05:09 --> Security Class Initialized
DEBUG - 2026-05-20 17:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:05:09 --> Input Class Initialized
INFO - 2026-05-20 17:05:09 --> Language Class Initialized
INFO - 2026-05-20 17:05:09 --> Loader Class Initialized
INFO - 2026-05-20 17:05:09 --> Helper loaded: url_helper
INFO - 2026-05-20 17:05:09 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:05:09 --> Controller Class Initialized
INFO - 2026-05-20 17:05:09 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:05:09 --> Helper loaded: form_helper
INFO - 2026-05-20 17:05:09 --> Form Validation Class Initialized
INFO - 2026-05-20 17:05:09 --> Final output sent to browser
DEBUG - 2026-05-20 17:05:09 --> Total execution time: 0.0988
INFO - 2026-05-20 17:05:09 --> Config Class Initialized
INFO - 2026-05-20 17:05:09 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:05:09 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:05:09 --> Utf8 Class Initialized
INFO - 2026-05-20 17:05:09 --> URI Class Initialized
INFO - 2026-05-20 17:05:09 --> Router Class Initialized
INFO - 2026-05-20 17:05:09 --> Output Class Initialized
INFO - 2026-05-20 17:05:09 --> Security Class Initialized
DEBUG - 2026-05-20 17:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:05:09 --> Input Class Initialized
INFO - 2026-05-20 17:05:09 --> Language Class Initialized
INFO - 2026-05-20 17:05:09 --> Loader Class Initialized
INFO - 2026-05-20 17:05:09 --> Helper loaded: url_helper
INFO - 2026-05-20 17:05:09 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:05:09 --> Controller Class Initialized
INFO - 2026-05-20 17:05:09 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:05:09 --> Model "Comment_model" initialized
INFO - 2026-05-20 17:05:09 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:05:09 --> Model "Message_model" initialized
INFO - 2026-05-20 17:05:09 --> Model "Order_model" initialized
INFO - 2026-05-20 17:05:09 --> Model "Setting_model" initialized
INFO - 2026-05-20 17:05:09 --> Helper loaded: form_helper
DEBUG - 2026-05-20 17:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:05:09 --> Upload Class Initialized
INFO - 2026-05-20 17:05:09 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/header.php
INFO - 2026-05-20 17:05:09 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\home.php
INFO - 2026-05-20 17:05:09 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/footer.php
INFO - 2026-05-20 17:05:09 --> Final output sent to browser
DEBUG - 2026-05-20 17:05:09 --> Total execution time: 0.0780
INFO - 2026-05-20 17:05:09 --> Config Class Initialized
INFO - 2026-05-20 17:05:09 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:05:09 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:05:09 --> Utf8 Class Initialized
INFO - 2026-05-20 17:05:09 --> URI Class Initialized
INFO - 2026-05-20 17:05:09 --> Router Class Initialized
INFO - 2026-05-20 17:05:09 --> Output Class Initialized
INFO - 2026-05-20 17:05:09 --> Security Class Initialized
DEBUG - 2026-05-20 17:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:05:09 --> Input Class Initialized
INFO - 2026-05-20 17:05:09 --> Language Class Initialized
INFO - 2026-05-20 17:05:09 --> Loader Class Initialized
INFO - 2026-05-20 17:05:09 --> Helper loaded: url_helper
INFO - 2026-05-20 17:05:09 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:05:09 --> Controller Class Initialized
INFO - 2026-05-20 17:05:09 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:05:09 --> Model "Order_model" initialized
INFO - 2026-05-20 17:05:09 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:05:09 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:05:09 --> Model "Message_model" initialized
INFO - 2026-05-20 17:05:09 --> Helper loaded: form_helper
INFO - 2026-05-20 17:05:09 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:05:09 --> Final output sent to browser
DEBUG - 2026-05-20 17:05:09 --> Total execution time: 0.0905
INFO - 2026-05-20 17:05:29 --> Config Class Initialized
INFO - 2026-05-20 17:05:29 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:05:29 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:05:29 --> Utf8 Class Initialized
INFO - 2026-05-20 17:05:29 --> URI Class Initialized
INFO - 2026-05-20 17:05:29 --> Router Class Initialized
INFO - 2026-05-20 17:05:29 --> Output Class Initialized
INFO - 2026-05-20 17:05:29 --> Security Class Initialized
DEBUG - 2026-05-20 17:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:05:29 --> Input Class Initialized
INFO - 2026-05-20 17:05:29 --> Language Class Initialized
INFO - 2026-05-20 17:05:29 --> Loader Class Initialized
INFO - 2026-05-20 17:05:29 --> Helper loaded: url_helper
INFO - 2026-05-20 17:05:29 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:05:29 --> Controller Class Initialized
INFO - 2026-05-20 17:05:29 --> Model "Order_model" initialized
INFO - 2026-05-20 17:05:29 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:05:29 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:05:29 --> Model "Message_model" initialized
DEBUG - 2026-05-20 17:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:05:29 --> Helper loaded: form_helper
INFO - 2026-05-20 17:05:29 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/header.php
INFO - 2026-05-20 17:05:29 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\orders/index.php
INFO - 2026-05-20 17:05:29 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/footer.php
INFO - 2026-05-20 17:05:29 --> Final output sent to browser
DEBUG - 2026-05-20 17:05:29 --> Total execution time: 0.0628
INFO - 2026-05-20 17:05:36 --> Config Class Initialized
INFO - 2026-05-20 17:05:36 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:05:36 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:05:36 --> Utf8 Class Initialized
INFO - 2026-05-20 17:05:36 --> URI Class Initialized
INFO - 2026-05-20 17:05:36 --> Router Class Initialized
INFO - 2026-05-20 17:05:36 --> Output Class Initialized
INFO - 2026-05-20 17:05:36 --> Security Class Initialized
DEBUG - 2026-05-20 17:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:05:36 --> Input Class Initialized
INFO - 2026-05-20 17:05:36 --> Language Class Initialized
INFO - 2026-05-20 17:05:36 --> Loader Class Initialized
INFO - 2026-05-20 17:05:36 --> Helper loaded: url_helper
INFO - 2026-05-20 17:05:36 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:05:36 --> Controller Class Initialized
INFO - 2026-05-20 17:05:36 --> Model "Message_model" initialized
INFO - 2026-05-20 17:05:36 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:05:36 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:05:36 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:05:36 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/header.php
INFO - 2026-05-20 17:05:36 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\messages/inbox.php
INFO - 2026-05-20 17:05:36 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/footer.php
INFO - 2026-05-20 17:05:36 --> Final output sent to browser
DEBUG - 2026-05-20 17:05:36 --> Total execution time: 0.0460
INFO - 2026-05-20 17:05:38 --> Config Class Initialized
INFO - 2026-05-20 17:05:38 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:05:38 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:05:38 --> Utf8 Class Initialized
INFO - 2026-05-20 17:05:38 --> URI Class Initialized
INFO - 2026-05-20 17:05:38 --> Router Class Initialized
INFO - 2026-05-20 17:05:38 --> Output Class Initialized
INFO - 2026-05-20 17:05:38 --> Security Class Initialized
DEBUG - 2026-05-20 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:05:38 --> Input Class Initialized
INFO - 2026-05-20 17:05:38 --> Language Class Initialized
INFO - 2026-05-20 17:05:38 --> Loader Class Initialized
INFO - 2026-05-20 17:05:38 --> Helper loaded: url_helper
INFO - 2026-05-20 17:05:38 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:05:38 --> Controller Class Initialized
INFO - 2026-05-20 17:05:38 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:05:38 --> Model "Comment_model" initialized
INFO - 2026-05-20 17:05:38 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:05:38 --> Model "Message_model" initialized
INFO - 2026-05-20 17:05:38 --> Model "Order_model" initialized
INFO - 2026-05-20 17:05:38 --> Model "Setting_model" initialized
INFO - 2026-05-20 17:05:38 --> Helper loaded: form_helper
DEBUG - 2026-05-20 17:05:38 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:05:38 --> Upload Class Initialized
INFO - 2026-05-20 17:05:38 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/header.php
INFO - 2026-05-20 17:05:38 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\home.php
INFO - 2026-05-20 17:05:38 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/footer.php
INFO - 2026-05-20 17:05:38 --> Final output sent to browser
DEBUG - 2026-05-20 17:05:38 --> Total execution time: 0.0646
INFO - 2026-05-20 17:05:38 --> Config Class Initialized
INFO - 2026-05-20 17:05:38 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:05:38 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:05:38 --> Utf8 Class Initialized
INFO - 2026-05-20 17:05:38 --> URI Class Initialized
INFO - 2026-05-20 17:05:38 --> Router Class Initialized
INFO - 2026-05-20 17:05:38 --> Output Class Initialized
INFO - 2026-05-20 17:05:38 --> Security Class Initialized
DEBUG - 2026-05-20 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:05:38 --> Input Class Initialized
INFO - 2026-05-20 17:05:38 --> Language Class Initialized
INFO - 2026-05-20 17:05:38 --> Loader Class Initialized
INFO - 2026-05-20 17:05:38 --> Helper loaded: url_helper
INFO - 2026-05-20 17:05:38 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:05:38 --> Controller Class Initialized
INFO - 2026-05-20 17:05:38 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:05:38 --> Model "Order_model" initialized
INFO - 2026-05-20 17:05:38 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:05:38 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:05:38 --> Model "Message_model" initialized
INFO - 2026-05-20 17:05:38 --> Helper loaded: form_helper
INFO - 2026-05-20 17:05:38 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:05:38 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:05:38 --> Final output sent to browser
DEBUG - 2026-05-20 17:05:38 --> Total execution time: 0.0735
INFO - 2026-05-20 17:05:42 --> Config Class Initialized
INFO - 2026-05-20 17:05:42 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:05:42 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:05:42 --> Utf8 Class Initialized
INFO - 2026-05-20 17:05:42 --> URI Class Initialized
INFO - 2026-05-20 17:05:42 --> Router Class Initialized
INFO - 2026-05-20 17:05:42 --> Output Class Initialized
INFO - 2026-05-20 17:05:42 --> Security Class Initialized
DEBUG - 2026-05-20 17:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:05:42 --> Input Class Initialized
INFO - 2026-05-20 17:05:42 --> Language Class Initialized
INFO - 2026-05-20 17:05:42 --> Loader Class Initialized
INFO - 2026-05-20 17:05:42 --> Helper loaded: url_helper
INFO - 2026-05-20 17:05:42 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:05:42 --> Controller Class Initialized
INFO - 2026-05-20 17:05:42 --> Model "Message_model" initialized
INFO - 2026-05-20 17:05:42 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:05:42 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:05:42 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/header.php
INFO - 2026-05-20 17:05:42 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\messages/conversation.php
INFO - 2026-05-20 17:05:42 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/footer.php
INFO - 2026-05-20 17:05:42 --> Final output sent to browser
DEBUG - 2026-05-20 17:05:42 --> Total execution time: 0.0518
INFO - 2026-05-20 17:05:44 --> Config Class Initialized
INFO - 2026-05-20 17:05:44 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:05:44 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:05:44 --> Utf8 Class Initialized
INFO - 2026-05-20 17:05:44 --> URI Class Initialized
INFO - 2026-05-20 17:05:44 --> Router Class Initialized
INFO - 2026-05-20 17:05:44 --> Output Class Initialized
INFO - 2026-05-20 17:05:44 --> Security Class Initialized
DEBUG - 2026-05-20 17:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:05:44 --> Input Class Initialized
INFO - 2026-05-20 17:05:44 --> Language Class Initialized
INFO - 2026-05-20 17:05:44 --> Loader Class Initialized
INFO - 2026-05-20 17:05:44 --> Helper loaded: url_helper
INFO - 2026-05-20 17:05:44 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:05:44 --> Controller Class Initialized
INFO - 2026-05-20 17:05:44 --> Model "Message_model" initialized
INFO - 2026-05-20 17:05:44 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:05:44 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:05:44 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/header.php
INFO - 2026-05-20 17:05:44 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\messages/inbox.php
INFO - 2026-05-20 17:05:44 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/footer.php
INFO - 2026-05-20 17:05:44 --> Final output sent to browser
DEBUG - 2026-05-20 17:05:44 --> Total execution time: 0.0297
INFO - 2026-05-20 17:06:02 --> Config Class Initialized
INFO - 2026-05-20 17:06:02 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:06:02 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:06:02 --> Utf8 Class Initialized
INFO - 2026-05-20 17:06:02 --> URI Class Initialized
INFO - 2026-05-20 17:06:02 --> Router Class Initialized
INFO - 2026-05-20 17:06:02 --> Output Class Initialized
INFO - 2026-05-20 17:06:02 --> Security Class Initialized
DEBUG - 2026-05-20 17:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:06:02 --> Input Class Initialized
INFO - 2026-05-20 17:06:02 --> Language Class Initialized
INFO - 2026-05-20 17:06:02 --> Loader Class Initialized
INFO - 2026-05-20 17:06:02 --> Helper loaded: url_helper
INFO - 2026-05-20 17:06:02 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:06:02 --> Controller Class Initialized
INFO - 2026-05-20 17:06:02 --> Model "Message_model" initialized
INFO - 2026-05-20 17:06:02 --> Model "Auth_model" initialized
DEBUG - 2026-05-20 17:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:06:02 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:06:02 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/header.php
INFO - 2026-05-20 17:06:02 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\messages/inbox.php
INFO - 2026-05-20 17:06:02 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/footer.php
INFO - 2026-05-20 17:06:02 --> Final output sent to browser
DEBUG - 2026-05-20 17:06:02 --> Total execution time: 0.0443
INFO - 2026-05-20 17:06:08 --> Config Class Initialized
INFO - 2026-05-20 17:06:08 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:06:08 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:06:08 --> Utf8 Class Initialized
INFO - 2026-05-20 17:06:08 --> URI Class Initialized
INFO - 2026-05-20 17:06:08 --> Router Class Initialized
INFO - 2026-05-20 17:06:08 --> Output Class Initialized
INFO - 2026-05-20 17:06:08 --> Security Class Initialized
DEBUG - 2026-05-20 17:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:06:08 --> Input Class Initialized
INFO - 2026-05-20 17:06:08 --> Language Class Initialized
INFO - 2026-05-20 17:06:08 --> Loader Class Initialized
INFO - 2026-05-20 17:06:08 --> Helper loaded: url_helper
INFO - 2026-05-20 17:06:08 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:06:08 --> Controller Class Initialized
INFO - 2026-05-20 17:06:08 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:06:08 --> Model "Comment_model" initialized
INFO - 2026-05-20 17:06:08 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:06:08 --> Model "Message_model" initialized
INFO - 2026-05-20 17:06:08 --> Model "Order_model" initialized
INFO - 2026-05-20 17:06:08 --> Model "Setting_model" initialized
INFO - 2026-05-20 17:06:08 --> Helper loaded: form_helper
DEBUG - 2026-05-20 17:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:06:08 --> Upload Class Initialized
INFO - 2026-05-20 17:06:08 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/header.php
INFO - 2026-05-20 17:06:08 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\home.php
INFO - 2026-05-20 17:06:08 --> File loaded: C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\application\views\partials/footer.php
INFO - 2026-05-20 17:06:08 --> Final output sent to browser
DEBUG - 2026-05-20 17:06:08 --> Total execution time: 0.0822
INFO - 2026-05-20 17:06:08 --> Config Class Initialized
INFO - 2026-05-20 17:06:08 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:06:08 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:06:08 --> Utf8 Class Initialized
INFO - 2026-05-20 17:06:08 --> URI Class Initialized
INFO - 2026-05-20 17:06:08 --> Router Class Initialized
INFO - 2026-05-20 17:06:08 --> Output Class Initialized
INFO - 2026-05-20 17:06:08 --> Security Class Initialized
DEBUG - 2026-05-20 17:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:06:08 --> Input Class Initialized
INFO - 2026-05-20 17:06:08 --> Language Class Initialized
INFO - 2026-05-20 17:06:08 --> Loader Class Initialized
INFO - 2026-05-20 17:06:08 --> Helper loaded: url_helper
INFO - 2026-05-20 17:06:08 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:06:08 --> Controller Class Initialized
INFO - 2026-05-20 17:06:08 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:06:08 --> Model "Order_model" initialized
INFO - 2026-05-20 17:06:08 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:06:08 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:06:08 --> Model "Message_model" initialized
INFO - 2026-05-20 17:06:08 --> Helper loaded: form_helper
INFO - 2026-05-20 17:06:08 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:06:08 --> Final output sent to browser
DEBUG - 2026-05-20 17:06:08 --> Total execution time: 0.0813
INFO - 2026-05-20 17:06:09 --> Config Class Initialized
INFO - 2026-05-20 17:06:09 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:06:09 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:06:09 --> Utf8 Class Initialized
INFO - 2026-05-20 17:06:09 --> URI Class Initialized
INFO - 2026-05-20 17:06:09 --> Router Class Initialized
INFO - 2026-05-20 17:06:09 --> Output Class Initialized
INFO - 2026-05-20 17:06:09 --> Security Class Initialized
DEBUG - 2026-05-20 17:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:06:09 --> Input Class Initialized
INFO - 2026-05-20 17:06:09 --> Language Class Initialized
INFO - 2026-05-20 17:06:09 --> Loader Class Initialized
INFO - 2026-05-20 17:06:09 --> Helper loaded: url_helper
INFO - 2026-05-20 17:06:09 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:06:09 --> Controller Class Initialized
INFO - 2026-05-20 17:06:09 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:06:09 --> Model "Order_model" initialized
INFO - 2026-05-20 17:06:09 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:06:09 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:06:09 --> Model "Message_model" initialized
INFO - 2026-05-20 17:06:09 --> Helper loaded: form_helper
INFO - 2026-05-20 17:06:09 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:06:09 --> Final output sent to browser
DEBUG - 2026-05-20 17:06:09 --> Total execution time: 0.0796
INFO - 2026-05-20 17:06:10 --> Config Class Initialized
INFO - 2026-05-20 17:06:10 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:06:10 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:06:10 --> Utf8 Class Initialized
INFO - 2026-05-20 17:06:10 --> URI Class Initialized
INFO - 2026-05-20 17:06:10 --> Router Class Initialized
INFO - 2026-05-20 17:06:10 --> Output Class Initialized
INFO - 2026-05-20 17:06:10 --> Security Class Initialized
DEBUG - 2026-05-20 17:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:06:10 --> Input Class Initialized
INFO - 2026-05-20 17:06:10 --> Language Class Initialized
INFO - 2026-05-20 17:06:10 --> Loader Class Initialized
INFO - 2026-05-20 17:06:10 --> Helper loaded: url_helper
INFO - 2026-05-20 17:06:10 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:06:10 --> Controller Class Initialized
INFO - 2026-05-20 17:06:10 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:06:10 --> Model "Order_model" initialized
INFO - 2026-05-20 17:06:10 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:06:10 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:06:10 --> Model "Message_model" initialized
INFO - 2026-05-20 17:06:10 --> Helper loaded: form_helper
INFO - 2026-05-20 17:06:10 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:06:10 --> Final output sent to browser
DEBUG - 2026-05-20 17:06:10 --> Total execution time: 0.0973
INFO - 2026-05-20 17:06:10 --> Config Class Initialized
INFO - 2026-05-20 17:06:10 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:06:10 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:06:10 --> Utf8 Class Initialized
INFO - 2026-05-20 17:06:10 --> URI Class Initialized
INFO - 2026-05-20 17:06:10 --> Router Class Initialized
INFO - 2026-05-20 17:06:10 --> Output Class Initialized
INFO - 2026-05-20 17:06:10 --> Security Class Initialized
DEBUG - 2026-05-20 17:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:06:10 --> Input Class Initialized
INFO - 2026-05-20 17:06:10 --> Language Class Initialized
INFO - 2026-05-20 17:06:10 --> Loader Class Initialized
INFO - 2026-05-20 17:06:10 --> Helper loaded: url_helper
INFO - 2026-05-20 17:06:10 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:06:10 --> Controller Class Initialized
INFO - 2026-05-20 17:06:10 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:06:10 --> Model "Order_model" initialized
INFO - 2026-05-20 17:06:10 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:06:10 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:06:10 --> Model "Message_model" initialized
INFO - 2026-05-20 17:06:10 --> Helper loaded: form_helper
INFO - 2026-05-20 17:06:10 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:06:10 --> Final output sent to browser
DEBUG - 2026-05-20 17:06:10 --> Total execution time: 0.1178
INFO - 2026-05-20 17:06:12 --> Config Class Initialized
INFO - 2026-05-20 17:06:12 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:06:12 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:06:12 --> Utf8 Class Initialized
INFO - 2026-05-20 17:06:12 --> URI Class Initialized
INFO - 2026-05-20 17:06:12 --> Router Class Initialized
INFO - 2026-05-20 17:06:12 --> Output Class Initialized
INFO - 2026-05-20 17:06:12 --> Security Class Initialized
DEBUG - 2026-05-20 17:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:06:12 --> Input Class Initialized
INFO - 2026-05-20 17:06:12 --> Language Class Initialized
INFO - 2026-05-20 17:06:12 --> Loader Class Initialized
INFO - 2026-05-20 17:06:12 --> Helper loaded: url_helper
INFO - 2026-05-20 17:06:12 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:06:12 --> Controller Class Initialized
INFO - 2026-05-20 17:06:12 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:06:12 --> Model "Order_model" initialized
INFO - 2026-05-20 17:06:12 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:06:12 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:06:12 --> Model "Message_model" initialized
INFO - 2026-05-20 17:06:12 --> Helper loaded: form_helper
INFO - 2026-05-20 17:06:12 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:06:12 --> Final output sent to browser
DEBUG - 2026-05-20 17:06:12 --> Total execution time: 0.0756
INFO - 2026-05-20 17:06:12 --> Config Class Initialized
INFO - 2026-05-20 17:06:12 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:06:12 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:06:12 --> Utf8 Class Initialized
INFO - 2026-05-20 17:06:12 --> URI Class Initialized
INFO - 2026-05-20 17:06:12 --> Router Class Initialized
INFO - 2026-05-20 17:06:12 --> Output Class Initialized
INFO - 2026-05-20 17:06:12 --> Security Class Initialized
DEBUG - 2026-05-20 17:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:06:12 --> Input Class Initialized
INFO - 2026-05-20 17:06:12 --> Language Class Initialized
INFO - 2026-05-20 17:06:12 --> Loader Class Initialized
INFO - 2026-05-20 17:06:12 --> Helper loaded: url_helper
INFO - 2026-05-20 17:06:12 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:06:12 --> Controller Class Initialized
INFO - 2026-05-20 17:06:12 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:06:12 --> Model "Order_model" initialized
INFO - 2026-05-20 17:06:12 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:06:12 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:06:12 --> Model "Message_model" initialized
INFO - 2026-05-20 17:06:12 --> Helper loaded: form_helper
INFO - 2026-05-20 17:06:12 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:06:12 --> Final output sent to browser
DEBUG - 2026-05-20 17:06:12 --> Total execution time: 0.0878
INFO - 2026-05-20 17:06:13 --> Config Class Initialized
INFO - 2026-05-20 17:06:13 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:06:13 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:06:13 --> Utf8 Class Initialized
INFO - 2026-05-20 17:06:13 --> URI Class Initialized
INFO - 2026-05-20 17:06:13 --> Router Class Initialized
INFO - 2026-05-20 17:06:13 --> Output Class Initialized
INFO - 2026-05-20 17:06:13 --> Security Class Initialized
DEBUG - 2026-05-20 17:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:06:13 --> Input Class Initialized
INFO - 2026-05-20 17:06:13 --> Language Class Initialized
INFO - 2026-05-20 17:06:13 --> Loader Class Initialized
INFO - 2026-05-20 17:06:13 --> Helper loaded: url_helper
INFO - 2026-05-20 17:06:13 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:06:13 --> Controller Class Initialized
INFO - 2026-05-20 17:06:13 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:06:13 --> Model "Order_model" initialized
INFO - 2026-05-20 17:06:13 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:06:13 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:06:13 --> Model "Message_model" initialized
INFO - 2026-05-20 17:06:13 --> Helper loaded: form_helper
INFO - 2026-05-20 17:06:13 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:06:13 --> Final output sent to browser
DEBUG - 2026-05-20 17:06:13 --> Total execution time: 0.0981
INFO - 2026-05-20 17:06:13 --> Config Class Initialized
INFO - 2026-05-20 17:06:13 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:06:13 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:06:13 --> Utf8 Class Initialized
INFO - 2026-05-20 17:06:13 --> URI Class Initialized
INFO - 2026-05-20 17:06:13 --> Router Class Initialized
INFO - 2026-05-20 17:06:13 --> Output Class Initialized
INFO - 2026-05-20 17:06:13 --> Security Class Initialized
DEBUG - 2026-05-20 17:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:06:13 --> Input Class Initialized
INFO - 2026-05-20 17:06:13 --> Language Class Initialized
INFO - 2026-05-20 17:06:13 --> Loader Class Initialized
INFO - 2026-05-20 17:06:13 --> Helper loaded: url_helper
INFO - 2026-05-20 17:06:13 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:06:13 --> Controller Class Initialized
INFO - 2026-05-20 17:06:13 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:06:13 --> Model "Order_model" initialized
INFO - 2026-05-20 17:06:13 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:06:13 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:06:13 --> Model "Message_model" initialized
INFO - 2026-05-20 17:06:13 --> Helper loaded: form_helper
INFO - 2026-05-20 17:06:13 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:06:13 --> Final output sent to browser
DEBUG - 2026-05-20 17:06:13 --> Total execution time: 0.1557
INFO - 2026-05-20 17:06:13 --> Config Class Initialized
INFO - 2026-05-20 17:06:13 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:06:13 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:06:13 --> Utf8 Class Initialized
INFO - 2026-05-20 17:06:13 --> URI Class Initialized
INFO - 2026-05-20 17:06:13 --> Router Class Initialized
INFO - 2026-05-20 17:06:13 --> Output Class Initialized
INFO - 2026-05-20 17:06:13 --> Security Class Initialized
DEBUG - 2026-05-20 17:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:06:13 --> Input Class Initialized
INFO - 2026-05-20 17:06:13 --> Language Class Initialized
INFO - 2026-05-20 17:06:13 --> Loader Class Initialized
INFO - 2026-05-20 17:06:13 --> Helper loaded: url_helper
INFO - 2026-05-20 17:06:13 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:06:13 --> Controller Class Initialized
INFO - 2026-05-20 17:06:13 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:06:13 --> Model "Order_model" initialized
INFO - 2026-05-20 17:06:13 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:06:13 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:06:13 --> Model "Message_model" initialized
INFO - 2026-05-20 17:06:13 --> Helper loaded: form_helper
INFO - 2026-05-20 17:06:13 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:06:13 --> Final output sent to browser
DEBUG - 2026-05-20 17:06:13 --> Total execution time: 0.0784
INFO - 2026-05-20 17:06:14 --> Config Class Initialized
INFO - 2026-05-20 17:06:14 --> Hooks Class Initialized
DEBUG - 2026-05-20 17:06:14 --> UTF-8 Support Enabled
INFO - 2026-05-20 17:06:14 --> Utf8 Class Initialized
INFO - 2026-05-20 17:06:14 --> URI Class Initialized
INFO - 2026-05-20 17:06:14 --> Router Class Initialized
INFO - 2026-05-20 17:06:14 --> Output Class Initialized
INFO - 2026-05-20 17:06:14 --> Security Class Initialized
DEBUG - 2026-05-20 17:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-20 17:06:14 --> Input Class Initialized
INFO - 2026-05-20 17:06:14 --> Language Class Initialized
INFO - 2026-05-20 17:06:14 --> Loader Class Initialized
INFO - 2026-05-20 17:06:14 --> Helper loaded: url_helper
INFO - 2026-05-20 17:06:14 --> Database Driver Class Initialized
DEBUG - 2026-05-20 17:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-05-20 17:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-20 17:06:14 --> Controller Class Initialized
INFO - 2026-05-20 17:06:14 --> Model "Trade_model" initialized
INFO - 2026-05-20 17:06:14 --> Model "Order_model" initialized
INFO - 2026-05-20 17:06:14 --> Model "Seller_model" initialized
INFO - 2026-05-20 17:06:14 --> Model "Rating_model" initialized
INFO - 2026-05-20 17:06:14 --> Model "Message_model" initialized
INFO - 2026-05-20 17:06:14 --> Helper loaded: form_helper
INFO - 2026-05-20 17:06:14 --> Form Validation Class Initialized
DEBUG - 2026-05-20 17:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-20 17:06:14 --> Final output sent to browser
DEBUG - 2026-05-20 17:06:14 --> Total execution time: 0.1084
ERROR - 2026-05-20 19:15:45 --> Query error: MySQL server has gone away - Invalid query: INSERT INTO `hcmuepay_wallets` (`user_id`) VALUES ('4')
ERROR - 2026-05-20 19:15:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\PHP_CodeIgniter_TradingDocument\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2026-05-20 19:15:51 --> Unable to connect to the database
